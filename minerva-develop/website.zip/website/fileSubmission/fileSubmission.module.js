//File: fileSubmission.module.js
'use strict';

angular.module( 'website.fileSubmission', []);