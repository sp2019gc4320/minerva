//File: fieSubmission.controller.js
// Used with: fileSubmission.view.html

angular.module('website.fileSubmission').controller('fileSubmissionController', function ($scope, $http, $window) {
    //$scope.testData=["sally", "dick", "jane"];
});
