//File: editCoreComponent.module.js
'use strict';

angular.module( 'website.editCoreComponent', []);