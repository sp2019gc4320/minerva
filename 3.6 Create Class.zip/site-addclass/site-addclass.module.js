'use strict';
//Define the addClass module
angular.module('admin.addClass',[]);
