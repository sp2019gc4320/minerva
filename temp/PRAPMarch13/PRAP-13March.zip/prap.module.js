//File: prap.module.js
'use strict';

angular.module( 'notes.prap', []);
