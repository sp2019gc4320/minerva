'use strict';
//Define the viewGraduates module
angular.module('admin.siteViewGraduates',[]);