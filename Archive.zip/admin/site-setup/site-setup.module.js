'use strict';


//Define the siteSetup module'
angular.module( 'admin.siteSetup', []);
