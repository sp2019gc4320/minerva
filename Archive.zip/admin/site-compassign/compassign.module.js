'use strict';
//Define the compAssign module
angular.module('admin.compAssign',[]);
