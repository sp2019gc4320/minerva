'use strict';

//Define the 'main' module
angular.module('admin', [
    'admin.siteSetup',
    'admin.siteViewCadets',
    'admin.siteAddClass',
    'admin.siteAddCadet',
    'admin.siteViewGraduates',
    'admin.siteViewApplicants',
    'admin.compAssign',
    'admin.siteManagePermissions',
]);
