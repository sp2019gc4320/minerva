'use strict';

//Define the 'managePermissions' module
angular.module('admin.siteManagePermissions', []);
