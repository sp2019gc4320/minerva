'use strict';

//Define the 'addCadet' module
angular.module('admin.siteAddCadet', []);
