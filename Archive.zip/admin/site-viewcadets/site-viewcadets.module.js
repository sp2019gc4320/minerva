'use strict';
//Define the viewCadets module
angular.module('admin.siteViewCadets',[]);