'use strict';


//Define the site.lookups module'
angular.module( 'site.lookups', []);
