//File: site.module.js

'use strict';

angular.module('site', [
    'site.lookups'
]);