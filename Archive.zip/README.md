# Maintenance
Kali Kimball, Stephanie VanDyke, and Caleb Jones - SWE Final Project

## Reminders:
- Create new branch from master for each upload
- Delete branch after merging
- Update Trello after completing a task
