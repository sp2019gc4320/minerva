'use strict';


//Define the login module'
angular.module( 'utility.login', []);
