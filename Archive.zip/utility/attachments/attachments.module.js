// File: attachments.module.js
'use strict';

angular.module( 'utility.attachments', []);
