//File: utility.module.js

'use strict';

angular.module('utility', [
    'utility.attachments',
    'utility.login'

]);