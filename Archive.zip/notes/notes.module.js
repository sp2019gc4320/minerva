//File: notes.module.js

'use strict';

angular.module('notes', [
    'notes.prap',
    'notes.postres'
]);