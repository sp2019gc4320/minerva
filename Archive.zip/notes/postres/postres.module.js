//File: postres.module.js
'use strict';

angular.module( 'notes.postres', []);
