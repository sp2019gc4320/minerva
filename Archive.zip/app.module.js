//File: app.module.js

'use strict';

angular.module("myApp",[
    "ngRoute",
    "main",
    "admin",
    "website",
    "caseManager",
    "utility",
    "notes",
    "core-components",
    "site",
    "homescreen"
]);

var myApp = angular.module("myApp");