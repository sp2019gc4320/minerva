'use strict';


//Define the caseManager.cadetMentor module'
angular.module( 'caseManager.cadetMentor', []);
