'use strict';

//Define the 'caseManager' module
angular.module('caseManager', [
    'caseManager.cadetMentor'
]);