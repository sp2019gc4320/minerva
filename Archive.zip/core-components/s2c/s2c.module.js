//File: s2c.module.js
'use strict';

angular.module( 'core-components.s2c', []);
