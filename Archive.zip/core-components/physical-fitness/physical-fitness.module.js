//File: physical-fitness.module.js
'use strict';

angular.module( 'core-components.physical-fitness', []);
