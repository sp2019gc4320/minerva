//File: health.module.js
'use strict';

angular.module( 'core-components.health', []);
