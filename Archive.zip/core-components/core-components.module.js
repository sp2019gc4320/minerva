//File: core-components.module.js

'use strict';

angular.module('core-components', [
    'core-components.citizenship',
    'core-components.health',
    'core-components.lead-follow',
    'core-components.s2c',
    'core-components.job-skills'

]);