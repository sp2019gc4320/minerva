//File: citizenship.module.js
'use strict';

angular.module( 'core-components.citizenship', []);
