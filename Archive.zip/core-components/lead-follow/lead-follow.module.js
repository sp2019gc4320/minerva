//File: lead-follow.module.js
'use strict';

angular.module( 'core-components.lead-follow', []);
