//File: job-skills.module.js
'use strict';

angular.module( 'core-components.job-skills', []);
