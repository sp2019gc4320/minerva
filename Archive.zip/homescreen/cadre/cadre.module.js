//File: cadre.module.js

'use strict';

//Define the 'homescreen.cadre' module
angular.module('homescreen.cadre', []);

