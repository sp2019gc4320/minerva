//File: homescreen.module.js

'use strict';

angular.module('homescreen', [
    'homescreen.caseManager',
    'homescreen.cadre'
]);
