//File: case-manager.module.js

'use strict';

//Define the 'homescreen.caseManager' module
angular.module('homescreen.caseManager', []);